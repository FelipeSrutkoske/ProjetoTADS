// -------------- Exercicio 1 ------------------- //
var numero = prompt("Digite um numero");
numero = numero/2;
console.log("A metade do numero e:" numero);

// -------------- Exercicio 2 ------------------- //
var nome = prompt("Digite seu nome:");
var telefone = prompt("Digite seu telefone:");
var endereco = prompt("Digite seu endereco:");
console.log("Seu nome:" nome);
console.log("Seu telefone:" telefone);
console.log("Seu endereco:" endereco);

// -------------- Exercicio 3 ------------------- //
var numero1 = prompt("Digite um numero");
var numero2 = prompt("Digite um numero");
var numero3 = prompt("Digite um numero");
var numero4 = numero1+numero3-numero2;
console.log("A+C-B=" numero4);

// -------------- Exercicio 4 ------------------- //
var numero1 = prompt("Digite um numero");
var numero2 = prompt("Digite um numero");
var numero3 = prompt("Digite um numero");
var soma = numero1+numero2+numero3;
var subtracao = numero1-numero2-numero3;
var multi = numero1*numero2*numero3;
var divisao = numero1/numero2/numero3;
console.log("Soma:" soma);
console.log("Subtracao:" subtracao);
console.log("Multiplicacao:" multi);
console.log("Divisao:" divisao);

// -------------- Exercicio 5 ------------------- //
var base = prompt("Digite a base:");
var altura = prompt("Digite a altura:");
var area = (base*altura)/2;

// -------------- Exercicio 6 ------------------- //

// -------------- Exercicio 7 ------------------- //
const pi = (3,1415);
var raio = prompt("Digite o raio:");
var area = pi*((raio)*(raio));
console.log("Area do circulo:" area);

// -------------- Exercicio 8 ------------------- //

// -------------- Exercicio 9 ------------------- //
var salario = (1412);
var qw = (0,78);
var salario1 = prompt("Digite o salario:");
var qwgasto = prompt("Digite a quantia gasta:");
var valor = qw*qwgasto;
console.log("O valor gasto:" valor);

// -------------- Exercicio 10 ------------------- //
var chuva = prompt("Digite a quantia de chuva:");
var quantia = chuva*(25,4);
console.log("O valor em milimetros:" quantia);

// -------------- Exercicio 11 ------------------- //
var nota1 = prompt("Digite a nota 1:");
var nota2 = prompt("Digite a nota 2:");
var nota3 = prompt("Digite a nota 3:");
var nota4 = prompt("Digite a nota 4:");
var media = (nota1*nota2*nota3*nota4)/4;
console.log("A media: " media);

// -------------- Exercicio 12 ------------------- //

// -------------- Exercicio 13 ------------------- //
var valor = prompt("Digite o valor:");
var result = valor*(1,11);
var result = result*(1,11);
console.log("O resultado:" result);

// -------------- Exercicio 14 ------------------- //
var preco = prompt("Digite o valor:");
var desc = prompt("Digite o desconto:");
var desconto = preco*desc;
var final = preco*(1-(desc/100));
console.log("O valor do produto: " preco);
console.log("O valor do reajuste: " desc);
console.log("O valor do desconto: " desconto);
console.log("O valor final: " final);

// -------------- Exercicio 15 ------------------- //
var tempo = prompt("Digite a duracao da viagem: ");
var velocidade = prompt("Digite a velocidade media na viagem: ");
var distancia = tempo*velocidade;
var litros = distancia/16;
console.log("A distancia percorrida foi: " distancia);
console.log("A quantidade de litros gasta foi: " litros);

// -------------- Exercicio 16 ------------------- //
var hora = prompt("Digite a hora:");
var minuto = prompt("Digite os minutos:");
var segundo = prompt("Digite os segundos:");
var tempo = (hora*(3600))+(minuto*(60))+segundo;
console.log("O tempo em segundos foi: " tempo);
// -------------- Exercicio 17 ------------------- //

// -------------- Exercicio 18 ------------------- //
var valor1 = prompt("Digite o valor 1: ");
var raiz = ;
var quad = valor1*valor1;
console.log("O quadrado do numero: " quad);